interface DeepCloneable<T>
{
	public T deepClone();
}